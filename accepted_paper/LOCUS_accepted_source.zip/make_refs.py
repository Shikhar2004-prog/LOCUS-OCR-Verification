"""Write j_references.tex: the references in APA 7 style, numbered in order of first citation.

Order is read from locus_journal.aux (run pdflatex once first); unknown order falls back to the dict order.
"""
import os
import re

A = r"\textit"
REFS = {
    "fu2025ocrbenchv2": r"Fu, L., Kuang, Z., Song, J., Huang, M., Yang, B., Li, Y., Zhu, L., Luo, Q., Wang, X., Lu, H., Li, Z., Tang, G., Shan, B., Lin, C., Liu, Q., Wu, B., Feng, H., Liu, H., Huang, C., \ldots\ Bai, X. (2025). OCRBench v2: An improved benchmark for evaluating large multimodal models on visual text localization and reasoning. In \textit{Advances in Neural Information Processing Systems, Datasets and Benchmarks Track}.",
    "he2025seeing": r"He, Z., Zhang, C., Wu, Z., Chen, Z., Zhan, Y., Li, Y., Zhang, Z., Wang, X., \& Qiu, M. (2025). Seeing is believing? Mitigating OCR hallucinations in multimodal large language models. In \textit{Advances in Neural Information Processing Systems}.",
    "bautista2022parseq": r"Bautista, D., \& Atienza, R. (2022). Scene text recognition with permuted autoregressive sequence models. In \textit{Proceedings of the European Conference on Computer Vision (ECCV)} (pp.~178--196). Springer.",
    "li2023trocr": r"Li, M., Lv, T., Chen, J., Cui, L., Lu, Y., Florencio, D., Zhang, C., Li, Z., \& Wei, F. (2023). TrOCR: Transformer-based optical character recognition with pre-trained models. In \textit{Proceedings of the AAAI Conference on Artificial Intelligence}, \textit{37}(11), 13094--13102.",
    "xiao2024florence": r"Xiao, B., Wu, H., Xu, W., Dai, X., Hu, H., Lu, Y., Zeng, M., Liu, C., \& Yuan, L. (2024). Florence-2: Advancing a unified representation for a variety of vision tasks. In \textit{Proceedings of the IEEE/CVF Conference on Computer Vision and Pattern Recognition (CVPR)} (pp.~4818--4829).",
    "dubey2025hindi": r"Dubey, S., Mittal, K., Behera, S. K., Ravikiran, M., Kumar, N., Shigwan, S., \& Saluja, R. (2025). Multi-feature graph convolution network for Hindi OCR verification. In \textit{Proceedings of the 1st Workshop on Benchmarks, Harmonization, Annotation, and Standardization for Human-Centric AI in Indian Languages (BHASHA)} (pp.~1--10). Association for Computational Linguistics.",
    "kanerva2025nofree": r"Kanerva, J., Ledins, C., K\"apyaho, S., \& Ginter, F. (2025). OCR error post-correction with LLMs in historical documents: No free lunches. In \textit{Proceedings of the Third Workshop on Resources and Representations for Under-Resourced Languages and Domains (RESOURCEFUL)}.",
    "saxena2026reading": r"Saxena, S., Tripathi, V., \& Abbas, S. (2026). Reading between the characters: Label-efficient OCR verification with graph neural networks. In \textit{Proceedings of NICCAI 2026}, Hyderabad, India (to appear).",
    "leng2024vcd": r"Leng, S., Zhang, H., Chen, G., Li, X., Lu, S., Miao, C., \& Bing, L. (2024). Mitigating object hallucinations in large vision-language models through visual contrastive decoding. In \textit{Proceedings of the IEEE/CVF Conference on Computer Vision and Pattern Recognition (CVPR)} (pp.~13872--13882).",
    "brody2022gatv2": r"Brody, S., Alon, U., \& Yahav, E. (2022). How attentive are graph attention networks? In \textit{International Conference on Learning Representations (ICLR)}.",
    "jaume2019funsd": r"Jaume, G., Ekenel, H. K., \& Thiran, J.-P. (2019). FUNSD: A dataset for form understanding in noisy scanned documents. In \textit{International Conference on Document Analysis and Recognition Workshops (ICDARW)} (Vol.~2, pp.~1--6). IEEE.",
    "park2019cord": r"Park, S., Shin, S., Lee, B., Lee, J., Surh, J., Seo, M., \& Lee, H. (2019). CORD: A consolidated receipt dataset for post-OCR parsing. In \textit{Workshop on Document Intelligence at NeurIPS 2019}.",
    "huang2019sroie": r"Huang, Z., Chen, K., He, J., Bai, X., Karatzas, D., Lu, S., \& Jawahar, C. V. (2019). ICDAR2019 competition on scanned receipt OCR and information extraction. In \textit{International Conference on Document Analysis and Recognition (ICDAR)} (pp.~1516--1520). IEEE.",
    "corbiere2022confidence": r"Corbi\`ere, C., Thome, N., Saporta, A., Vu, T.-H., Cord, M., \& P\'erez, P. (2022). Confidence estimation via auxiliary models. \textit{IEEE Transactions on Pattern Analysis and Machine Intelligence}, \textit{44}(10), 6043--6055.",
    "bai2025qwen25vl": r"Qwen Team. (2025). \textit{Qwen2.5-VL-7B-Instruct} [Vision-language model]. Alibaba Cloud. \url{https://huggingface.co/Qwen/Qwen2.5-VL-7B-Instruct}",
    "kim2022donut": r"Kim, G., Hong, T., Yim, M., Nam, J., Park, J., Yim, J., Hwang, W., Yun, S., Han, D., \& Park, S. (2022). OCR-free document understanding transformer. In \textit{Proceedings of the European Conference on Computer Vision (ECCV)} (pp.~498--517). Springer.",
    "poznanski2026olmocr": r"Poznanski, J., Lo, K., \& Soldaini, L. (2026). The olmOCR project: Building fully open OCR using VLMs. In \textit{Proceedings of the 64th Annual Meeting of the Association for Computational Linguistics: System Demonstrations} (pp.~626--635). Association for Computational Linguistics.",
    "arazo2020pseudo": r"Arazo, E., Ortego, D., Albert, P., O'Connor, N. E., \& McGuinness, K. (2020). Pseudo-labeling and confirmation bias in deep semi-supervised learning. In \textit{International Joint Conference on Neural Networks (IJCNN)} (pp.~1--8). IEEE.",
    "sohn2020fixmatch": r"Sohn, K., Berthelot, D., Carlini, N., Zhang, Z., Zhang, H., Raffel, C. A., Cubuk, E. D., Kurakin, A., \& Li, C.-L. (2020). FixMatch: Simplifying semi-supervised learning with consistency and confidence. In \textit{Advances in Neural Information Processing Systems} (Vol.~33, pp.~596--608).",
    "minderer2021revisiting": r"Minderer, M., Djolonga, J., Romijnders, R., Hubis, F., Zhai, X., Houlsby, N., Tran, D., \& Lucic, M. (2021). Revisiting the calibration of modern neural networks. In \textit{Advances in Neural Information Processing Systems} (Vol.~34, pp.~15682--15694).",
    "alexandari2020maximum": r"Alexandari, A., Kundaje, A., \& Shrikumar, A. (2020). Maximum likelihood with bias-corrected calibration is hard-to-beat at label shift adaptation. In \textit{Proceedings of the 37th International Conference on Machine Learning (ICML)} (pp.~222--232). PMLR.",
    "angelopoulos2023conformal": r"Angelopoulos, A. N., \& Bates, S. (2023). Conformal prediction: A gentle introduction. \textit{Foundations and Trends in Machine Learning}, \textit{16}(4), 494--591.",
    "tesseract2021": r"Tesseract OCR contributors. (2021). \textit{Tesseract OCR} (Version 5) [Computer software]. \url{https://github.com/tesseract-ocr/tesseract}",
}

here = os.path.dirname(os.path.abspath(__file__))
order = []
aux = os.path.join(here, "locus_journal.aux")
if os.path.exists(aux):
    for m in re.finditer(r"\\citation\{([^}]*)\}", open(aux).read()):
        for k in m.group(1).split(","):
            k = k.strip()
            if k in REFS and k not in order:
                order.append(k)
missing = [k for k in REFS if k not in order]
order += missing
unknown = set(re.findall(r"\\citation\{([^}]*)\}", open(aux).read()) if os.path.exists(aux) else [])
unknown = {k.strip() for g in unknown for k in g.split(",")} - set(REFS)
if unknown:
    print("CITED BUT NOT IN LIST:", unknown)
if missing and os.path.exists(aux):
    print("IN LIST BUT NEVER CITED:", missing)
out = [r"\begingroup\footnotesize\setlength{\parskip}{0pt}", r"\renewcommand{\refname}{\fontsize{12}{12}\selectfont\textbf{References}}",
       r"\begin{thebibliography}{99}\setlength{\itemsep}{1pt}"]
out += [rf"\bibitem{{{k}}} {REFS[k]}" for k in order]
out += [r"\end{thebibliography}", r"\endgroup"]
open(os.path.join(here, "j_references.tex"), "w").write("\n".join(out) + "\n")
print(len(order), "references written")
